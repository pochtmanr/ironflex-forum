import Trainings from '@/components/Pages/Trainings'

export default function TrainingsPage() {
  return <Trainings />
}

