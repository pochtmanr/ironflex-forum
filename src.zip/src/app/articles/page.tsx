import Articles from '@/components/Pages/Articles'

export default function ArticlesPage() {
  return <Articles />
}

