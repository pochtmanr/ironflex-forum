import CategoryView from '@/components/Forum/CategoryView'

export default function CategoryPage() {
  return <CategoryView />
}
