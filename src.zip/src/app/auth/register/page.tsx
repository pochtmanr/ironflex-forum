import Register from '@/components/Auth/Register'

export default function RegisterPage() {
  return <Register />
}
