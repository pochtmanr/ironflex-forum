import ForumHome from "@/components/Forum/ForumHome";

export default function Home() {
  return <ForumHome />;
}